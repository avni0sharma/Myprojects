package APITest;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class Postrequestmethod {

    @BeforeClass
    public void postrequestsetup() {

        RestAssured.baseURI = "https://maps.googleapis.com";
        RestAssured.basePath = "/maps/api";
    }


    @Test
    public void postRequestApi() {
        given()

                .queryParam("key" , "AIzaSyD_RUVRcvBbmzeoBoFIelic8OQXWHt8Yos")
                .body("{ \"location\": { \"lat\": -33.8669710, \"lng\": 151.1958750 }, \"accuracy\": 50, \"name\": \"Google Shoes!\", \"phone_number\": \"(02) 9374 4000\", \"address\": \"48 Pirrama Road, Pyrmont, NSW 2009, Australia\", \"types\": [\"shoe_store\"], \"website\": \"http://www.google.com.au/\", \"language\": \"en-AU\" }")


        .when()
              .post("/place/add/json")

        .then()
                .log()
                .ifError()
                .statusCode(404);
                //.body("scope" , equalTo("APP")).and()
                //.body("status" , equalTo("OK")).and()
               //.contentType(ContentType.JSON);
    }
}
