package APITest;

import io.restassured.RestAssured;
import models.PostAPIBody;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class Usingmodelforpostbody {

    @BeforeClass
    public void setuppostAPIMethod(){

        RestAssured.baseURI = "https://maps.googleapis.com";
        RestAssured.basePath = "/maps/api";
    }

    @Test
    public void postApimethod(){

        Map<String, Double> locationmap = new HashMap<String, Double>();
        locationmap.put("lat" , -33.8669710);
        locationmap.put("lng" , 151.1958750);

        ArrayList<String> types = new ArrayList<String>();
        types.add("shoe_store");

        PostAPIBody places = new PostAPIBody();

        places.setAccuracy(50);
        places.setAddress("48 Pirrama Road, Pyrmont, NSW 2009, Australia");
        places.setLanguage("en-AU");
        places.setName("Google Shoes!");
        places.setWebsite("http://www.google.com.au/");
        places.setLocation(locationmap);
        places.setTypes(types);

        given()
//                .log()
//                .all()
                .queryParam("key" , "AIzaSyD_RUVRcvBbmzeoBoFIelic8OQXWHt8Yos")
                .body(places)

                .when()
                .post("/place/add/json")
        .then()
                .statusCode(404);
    }
}
