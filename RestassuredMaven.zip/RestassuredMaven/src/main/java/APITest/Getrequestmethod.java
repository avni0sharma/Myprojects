package APITest;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;


public class Getrequestmethod {

    @BeforeClass
    public void setup(){
        RestAssured.baseURI = "https://maps.googleapis.com";
        RestAssured.basePath = "/maps/api";
    }

    @Test
    public void getRequestApi() {
        given()
                .param("units", "imperial")
                .param("origins" , "Washington,DC")
                .param("destinations" , "New+York+City,NY")
                .param("key","AIzaSyD_RUVRcvBbmzeoBoFIelic8OQXWHt8Yos")
                .when()
                    .get("/distancematrix/json")

                .then()
                .statusCode(200);
    }

    @Test
    public void getResponseBody() {

        Response res =
        given()
                .param("units", "imperial")
                .param("origins" , "Washington,DC")
                .param("destinations" , "New+York+City,NY")
                .param("key" , "AIzaSyD_RUVRcvBbmzeoBoFIelic8OQXWHt8Yos")
                .when()
                .get("/distancematrix/json");

            System.out.println(res.body().prettyPrint());
    }


}