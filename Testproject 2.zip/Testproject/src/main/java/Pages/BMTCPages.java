package Pages;


import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import org.springframework.stereotype.Component;



@Component("Pages.BMTCPages")
public class BMTCPages extends PageObject {


    @FindBy(xpath = ".//*[@id='block-locale-language']/div/div/ul/li[1]/a")
    private WebElementFacade languageSelection;



    @FindBy(xpath = "//li//a[@title = \"Home\"]")
    private WebElementFacade homeText;

    public void openBMTC(){ }

   // public void selectLanguage(){

     //   }


}
