package testrunnersteps.steps;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.joni.Config.log;

public class BMTCSteps extends ScenarioSteps {

    WebDriver driver;

    @Given("^BMTC site is opened$")
    public void bmtcSiteIsOpened() throws Throwable {
        System.out.println("launching chrome browser");
        driver = new ChromeDriver();
        log.checkError();
        driver.navigate().to("http://www.mybmtc.com/");
    }


    @When("^User convert to english$")
    public void userConvertToEnglish() throws Throwable {
        System.out.println("this is step 2");

        driver.findElement(By.id("kasdhashdahksj"));
        log.println();
    }

    @Then("^Verify page is in english$")
    public void verifyPageIsInEnglish() throws Throwable {
        System.out.println("This is step 3");
    }

    @When("^User enters from '(.*)'$")
    public void userEntersFromPlace(int arg0) throws Throwable {

        System.out.println("this is step 4");
    }

    @When("^User enters to 'place(\\d+)'$")
    public void userEntersToPlace(int arg0) throws Throwable {
        System.out.println("this is step 5");
    }

    @When("^User click search$")
    public void userClickSearch() throws Throwable {
        System.out.println("this is step 6");
    }

    @Then("^verify result is displayed$")
    public void verifyResultIsDisplayed() throws Throwable {
        System.out.println("this is step 7");
    }
}
