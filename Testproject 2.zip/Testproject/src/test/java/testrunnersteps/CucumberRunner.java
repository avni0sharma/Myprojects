package testrunnersteps;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)

@CucumberOptions(features = "src/test/resources/features/BMTC.feature",format = {"json:target/destination/cucumber.json"},



        tags = {"@FirstFeature1"})

        public class CucumberRunner {
}
